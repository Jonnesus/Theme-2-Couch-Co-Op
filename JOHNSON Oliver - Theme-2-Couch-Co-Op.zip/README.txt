Github URL: https://github.com/Jonnesus/Theme-2-Couch-Co-Op

This is an endless wave-spawning shooter. One player on keyboard, one player on controller, both players experiencing a lot of jank and scuff.

There were so many things I wanted to add to this, but it was (quite literally) finished in the eleventh hour.

I hate this.